package com.marc.app.recuuf1;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class CarteleraFragment extends Fragment {
    private CarteleraListener mListener;
    List<Pelicula> peliculas = new ArrayList<>();
    RecyclerView recyclerView;
    PeliculasAdapter peliculasAdapter;

    public CarteleraFragment() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_cartelera, container, false);

        mListener.obtenerCarteleraJSON();

        recyclerView = view.findViewById(R.id.recyclerPeliculas);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        peliculasAdapter = new PeliculasAdapter();
        recyclerView.setAdapter(peliculasAdapter);

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof CarteleraListener) {
            mListener = (CarteleraListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " debes implementar CarteleraListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public void cargarPeliculasRecycler(List<Pelicula> peliculasRecycler) {
        peliculas = peliculasRecycler;
        peliculasAdapter.notifyDataSetChanged();
    }

    public class PeliculasAdapter extends RecyclerView.Adapter<PeliculasAdapter.PeliculasViewHolder> {


        @NonNull
        @Override
        public PeliculasViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View itemView = getLayoutInflater().inflate(R.layout.pelicula_view_holder, viewGroup, false);
            return new PeliculasViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(@NonNull PeliculasViewHolder peliculasViewHolder, int i) {
            peliculasViewHolder.titulo.setText(peliculas.get(i).getTitulo());
            peliculasViewHolder.cines.setText(peliculas.get(i).getCines());
        }

        @Override
        public int getItemCount() {return peliculas.size();}

        public class PeliculasViewHolder extends RecyclerView.ViewHolder {
            TextView titulo, cines;

            public PeliculasViewHolder(@NonNull View itemView) {
                super(itemView);

                titulo = itemView.findViewById(R.id.tituloTextView);
                cines = itemView.findViewById(R.id.cinesTextView);

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        int position = getAdapterPosition();
                        mListener.cargarComentariosPelicula(peliculas.get(position));
                    }
                });
            }
        }
    }

    public interface CarteleraListener {
        void obtenerCarteleraJSON();

        void cargarComentariosPelicula(Pelicula pelicula);
    }
}
