package com.marc.app.recuuf1;

public class Comentario {
    String recomendada;
    String comentario;

    public Comentario() {
    }

    public Comentario(String recomendada, String comentario) {
        this.recomendada = recomendada;
        this.comentario = comentario;
    }

    public String getRecomendada() {
        return recomendada;
    }

    public void setRecomendada(String recomendada) {
        this.recomendada = recomendada;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }
}
