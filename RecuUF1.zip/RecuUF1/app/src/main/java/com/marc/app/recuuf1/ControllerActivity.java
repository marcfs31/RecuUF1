package com.marc.app.recuuf1;

import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class ControllerActivity extends AppCompatActivity implements CarteleraFragment.CarteleraListener, DetallePeliculaFragment.DetallePeliculaListener, NuevoComentarioFragment.NuevoComentarioListener {
    FirebaseDatabase firebaseDatabase;
    List<Comentario> comentarios = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_controller);

        // Cargar fragment inicial con la imagen
        Fragment fragment = new InicioFragment();
        cargarFragment(fragment, "INICIO"); // Esto no haría falta
        Log.i("INICIO", "Fragment cargado correctamente");

        // Firebase
        firebaseDatabase = FirebaseDatabase.getInstance();
    }

    private void cargarFragment(Fragment fragment, String etiqueta) {
        // Poner el fragment en el fragment controller(ControllerActivity)
        getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainer, fragment, etiqueta).addToBackStack(null).commit();
    }

    // Menus de arriba
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.loginBtn:

                return true;

            case R.id.carteleraBtn:
                Fragment fragment = new CarteleraFragment();
                cargarFragment(fragment, "CARTELERA");
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    // Metodos de los fragments que implementamos
    @Override
    public void obtenerCarteleraJSON() {
        // Creamos una instancia del Hilo y lo ejecutamos pasando la URL de donde sacar el JSON
        MiHilo miHilo = new MiHilo();
        miHilo.execute("https://jdarestaurant.firebaseio.com/comentarios.json");

    }

    @Override
    public void cargarComentariosPelicula(Pelicula pelicula) {
        firebaseDatabase.getReference().child("comentarios").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Comentario comentario;
                comentario = dataSnapshot.getValue(Comentario.class);
                comentarios.add(comentario);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {}

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {}

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {}

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {}
        });
    }

    @Override
    public void recuperarComentarios() {
        DetallePeliculaFragment fragment = new DetallePeliculaFragment();
        cargarFragment(fragment, "COMENTARIOS");

        DetallePeliculaFragment fragment2 = (DetallePeliculaFragment) getSupportFragmentManager().findFragmentByTag("COMENTARIOS");
        fragment2.cargarComentariosRecycler(comentarios);

    }

    @Override
    public void crearComentarioDetalle() {
        crearComentario();
    }

    @Override
    public void crearComentario() {
        Fragment fragment = new NuevoComentarioFragment();
        cargarFragment(fragment, "COMENTARIO");
    }


    // Hilo para conectarse a internet y bajar los datos del json
    public class MiHilo extends AsyncTask<String,Void,String> {

        // Se ejecuta de fondo y descarga el JSON
        @Override
        protected String doInBackground(String... strings) {

            HttpURLConnection connection;
            URL url;
            connection = null;
            String result;
            result ="";

            try{

                url = new URL(strings[0]);
                connection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = connection.getInputStream();

                int data = inputStream.read();

                while(data != -1){
                    result += (char) data;
                    data = inputStream.read();
                }

            }catch (Exception e){

                e.printStackTrace();

            }

            Log.i("RESULT", result);
            return result;
        }

        // Cuando se acaba de ejecutar el hilo
        @Override
        protected void onPostExecute(String data) {
            super.onPostExecute(data);
            Log.i("JSON", data);

            List<Pelicula> peliculasRecycler = new ArrayList<>();

            try {
                // Por cada array [] que tenga el json uno de estos
                JSONArray jsonArrayPeliculas = new JSONArray(data);

                Log.i("Peliculas", jsonArrayPeliculas.toString());

                for(int i=0; i<jsonArrayPeliculas.length(); i++){
                    JSONObject jsonitem = jsonArrayPeliculas.getJSONObject(i);

                    String salas = "";

                    JSONArray salasArray = jsonitem.getJSONArray("salas");

                    for(int x=0; x<salasArray.length(); x++) {
                        JSONObject jsonObjectSala = salasArray.getJSONObject(x);
                        salas = salas + jsonObjectSala.getString("cine")+ ", ";
                    }

                    Pelicula plato = new Pelicula(jsonitem.getString("titulo"), salas);

                    peliculasRecycler.add(plato);
                }


                // Buscamos el fragment instanciado antes con la etiqueta JSON
                CarteleraFragment fragment = (CarteleraFragment) getSupportFragmentManager().findFragmentByTag("CARTELERA");
                fragment.cargarPeliculasRecycler(peliculasRecycler); // Le pasamos las comentarios sacadas de la URL de JSON

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}
