package com.marc.app.recuuf1;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class DetallePeliculaFragment extends Fragment {
    private DetallePeliculaListener mListener;
    List<Comentario> comentarios = new ArrayList<>();
    RecyclerView recyclerView;
    ComentariosAdapter comentariosAdapter;
    Button nuevoComentarioBtn;

    public DetallePeliculaFragment() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_detalle_pelicula, container, false);

        mListener.recuperarComentarios();

        recyclerView = view.findViewById(R.id.recyclerComentarios);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        comentariosAdapter = new ComentariosAdapter();
        recyclerView.setAdapter(comentariosAdapter);

        nuevoComentarioBtn = view.findViewById(R.id.nuevoComentarioBtn);

        nuevoComentarioBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.crearComentarioDetalle();
            }
        });

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof DetallePeliculaListener) {
            mListener = (DetallePeliculaListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " debes implementar DetallePeliculaListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public void cargarComentariosRecycler(List<Comentario> comentariosRecycler) {
        comentarios = comentariosRecycler;
        comentariosAdapter.notifyDataSetChanged();
    }

    public class ComentariosAdapter extends RecyclerView.Adapter<ComentariosAdapter.ComentariosViewHolder> {


        @NonNull
        @Override
        public ComentariosViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View itemView = getLayoutInflater().inflate(R.layout.comentario_view_holder, viewGroup, false);
            return new ComentariosViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(@NonNull ComentariosViewHolder comentariosViewHolder, int i) {
            comentariosViewHolder.recomendada.setText(comentarios.get(i).getRecomendada());
            comentariosViewHolder.comentario.setText(comentarios.get(i).getComentario());
        }

        @Override
        public int getItemCount() {return comentarios.size();}

        public class ComentariosViewHolder extends RecyclerView.ViewHolder {
            TextView recomendada, comentario;

            public ComentariosViewHolder(@NonNull View itemView) {
                super(itemView);

                recomendada = itemView.findViewById(R.id.recomendadaTextView);
                comentario = itemView.findViewById(R.id.comentarioTextView);
            }
        }
    }

    public interface DetallePeliculaListener {
        void recuperarComentarios();
        void crearComentarioDetalle();
    }
}
