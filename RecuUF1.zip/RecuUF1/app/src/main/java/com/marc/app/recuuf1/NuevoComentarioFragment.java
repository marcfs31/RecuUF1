package com.marc.app.recuuf1;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.FirebaseDatabase;

import org.w3c.dom.Text;

import java.util.UUID;

public class NuevoComentarioFragment extends Fragment {
    private NuevoComentarioListener mListener;
    EditText recomiendasEditText, comentariosNuevoEditText;
    Button subirBtn;
    FirebaseDatabase firebaseDatabase;

    public NuevoComentarioFragment() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_nuevo_comentario, container, false);

        recomiendasEditText = view.findViewById(R.id.recomiendasEditText);
        comentariosNuevoEditText = view.findViewById(R.id.comentariosNuevoEditText);
        subirBtn = view.findViewById(R.id.subirBtn);

        firebaseDatabase = FirebaseDatabase.getInstance();

        subirBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Comentario comentario = new Comentario();
                comentario.setComentario(comentariosNuevoEditText.getText().toString());
                comentario.setRecomendada(recomiendasEditText.getText().toString());
                UUID uuid = UUID.randomUUID();
                firebaseDatabase.getReference().child("comentarios").child(uuid.toString()).setValue(comentario);
            }
        });
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof NuevoComentarioListener) {
            mListener = (NuevoComentarioListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement NuevoComentarioListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface NuevoComentarioListener {
        void crearComentario();
    }
}
