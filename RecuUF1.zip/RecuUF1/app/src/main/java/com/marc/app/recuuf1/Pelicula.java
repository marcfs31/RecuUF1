package com.marc.app.recuuf1;

public class Pelicula {
    String titulo;
    String cines;

    public Pelicula() {
    }

    public Pelicula(String titulo, String cines) {
        this.titulo = titulo;
        this.cines = cines;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getCines() {
        return cines;
    }

    public void setCines(String cines) {
        this.cines = cines;
    }
}
